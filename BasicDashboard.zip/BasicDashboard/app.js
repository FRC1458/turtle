var heightPercent = 80;

$(document).ready(function() {
    var canvas = document.getElementById("canvas");
    var draw = canvas.getContext("2d");

    draw.lineWidth = 2;
    draw.strokeStyle = "black";
    draw.beginPath();
    draw.moveTo(0, 77);
    draw.lineTo(1000, 77);
    draw.stroke();

    draw.lineWidth = 2;
    draw.strokeStyle = "black";
    draw.beginPath();
    draw.moveTo(0, 73);
    draw.lineTo(1000, 73);
    draw.stroke();

    draw.lineWidth = 2;
    draw.strokeStyle = "hotpink";
    draw.beginPath();
    draw.moveTo(0, 75);
    draw.lineTo(1000, 75);
    draw.stroke();

    var height = 300.0*heightPercent/100.0;

    draw.lineWidth = 2;
    draw.strokeStyle = "hotpink";
    draw.beginPath();
    draw.moveTo(height, 0);
    draw.lineTo(height, 10000);
    draw.stroke();


    draw.lineWidth = 2;
    draw.strokeStyle = "black";
    draw.beginPath();
    draw.moveTo(height-2, 0);
    draw.lineTo(height-2, 10000);
    draw.stroke();


    draw.lineWidth = 2;
    draw.strokeStyle = "black";
    draw.beginPath();
    draw.moveTo(height+2, 0);
    draw.lineTo(height+2, 10000);
    draw.stroke();
});

function refreshBtn() {
    document.location.reload();
}